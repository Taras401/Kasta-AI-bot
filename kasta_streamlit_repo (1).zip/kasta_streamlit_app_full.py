
import streamlit as st
import pandas as pd
import random

st.set_page_config(page_title="Kasta AI Бот", layout="wide")
st.title("🛍️ Kasta AI бот: Генерація викладки товарів")

uploaded_file = st.file_uploader("Завантаж Excel-файл з товарами", type=["xlsx"])

if uploaded_file:
    df = pd.read_excel(uploaded_file)
    st.success(f"✅ Файл містить {len(df)} рядків.")

    if 'articule' in df.columns:
        st.subheader("📦 Попередній перегляд артикулів:")
        st.dataframe(df[['articule']].head(100))

    cols_needed = ['_60d_gross_sales_revenue', '_60d_wishlist_user_count', '_60d_page_view_cnt']
    numeric_cols = [col for col in cols_needed if col in df.columns]
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    df['score'] = df[numeric_cols].sum(axis=1)
    top_df = df.sort_values(by='score', ascending=False).head(100).copy()

    st.subheader("🏆 Топ-100 товарів")
    st.dataframe(top_df[['articule'] + numeric_cols])

    st.subheader("📊 Загальна аналітика по всьому файлу")
    for col in numeric_cols:
        st.markdown(f"**{col}:**")
        st.write(f"🔹 Середнє: {df[col].mean():.2f}")
        st.write(f"🔹 Медіана: {df[col].median():.2f}")
        st.write(f"🔹 Мінімум: {df[col].min():.2f}")
        st.write(f"🔹 Максимум: {df[col].max():.2f}")

    st.subheader("📈 Бар-чарт по середніх значеннях")
    mean_data = {col: df[col].mean() for col in numeric_cols}
    mean_df = pd.DataFrame.from_dict(mean_data, orient='index', columns=['mean'])
    st.bar_chart(mean_df)

    st.subheader("📝 Згенерований опис до акції")
    example_products = top_df['articule'].astype(str).head(5).tolist()
    promo_text = f"🔥 Не пропустіть найкращі товари акції: {', '.join(example_products)}. Обирайте швидше — поки вони ще в наявності!"
    st.markdown(promo_text)
else:
    st.warning("⚠️ Будь ласка, завантажте Excel-файл для початку роботи.")
